const { Subject } = rxjs;
// const { catchError, retry } = rxjs.operators;

function print(val) {
    let el = document.createElement('p');
    el.innerText = val;
    document.body.appendChild(el);
}

// Acts like a normal observable.
// Effectively broadcasts data to subscribers without relying
// on source data.
const subject = new Subject();
const subscriberA = subject.subscribe(val => print(`Subscriber A: ${val}`));
const subscriberB = subject.subscribe(val => print(`Subscriber B: ${val}`));

// Can also call next on it.
subject.next('Hello');

// Another next.
setTimeout(() => {
    subject.next('World');
}, 1000);
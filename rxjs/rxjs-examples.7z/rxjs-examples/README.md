# RxJS Example

## Intro
Some RxJS examples.

## Run
Run with: browser-sync start -s --watch --files "*.html"

Alternatively: npm install http-server -g http-server -o -c-1

## Examples

### simple